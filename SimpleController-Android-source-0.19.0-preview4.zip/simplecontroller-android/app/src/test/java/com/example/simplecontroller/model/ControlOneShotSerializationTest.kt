package com.example.simplecontroller.model

import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ControlOneShotSerializationTest {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    @Test
    fun oldLayoutControl_usesSafeOneShotDefaults() {
        val oldJson = """
            {
              "id":"legacy",
              "type":"BUTTON",
              "x":1.0,
              "y":2.0,
              "w":100.0,
              "h":100.0,
              "payload":"X360A",
              "buttonAimEnabled":true,
              "buttonAimOutput":"RIGHT_STICK"
            }
        """.trimIndent()

        val control = json.decodeFromString<Control>(oldJson)

        assertFalse(control.autoTapEnabled)
        assertEquals(100L, control.autoTapIntervalMs)
        assertFalse(control.buttonAimOneShotAlternateEnabled)
        assertEquals("", control.buttonAimAlternatePayload)
        assertEquals(ButtonAimPayloadTiming.IMMEDIATE, control.buttonAimAlternatePayloadTiming)
        assertEquals(2000L, control.buttonAimAlternateResetHoldDurationMs)
        assertEquals(0L, control.buttonAimAlternateBaseUnlatchDelayMs)
        assertEquals(ButtonAimOutput.MOUSE, control.buttonAimAlternateOutput)
        assertTrue(control.buttonAimAutoCenter)
        assertTrue(control.buttonAimAlternateAutoCenter)
        assertFalse(control.buttonAimStickUsesTouchPosition)
        assertFalse(control.buttonAimAlternateStickUsesTouchPosition)
        assertEquals(ButtonAimStickProfile.LINEAR, control.buttonAimStickProfile)
        assertEquals(ButtonAimStickProfile.LINEAR, control.buttonAimAlternateStickProfile)
        assertEquals(ButtonAimDpadMode.EIGHT_WAY, control.buttonAimDpadMode)
        assertEquals(ButtonAimDpadOrigin.CONTROL_CENTER, control.buttonAimDpadOrigin)
        assertEquals(8f, control.buttonAimDpadActivationDistancePx)
    }

    @Test
    fun independentAlternateSettings_roundTrip() {
        val source = Control(
            id = "alternate",
            type = ControlType.BUTTON,
            x = 1f,
            y = 2f,
            w = 100f,
            h = 100f,
            payload = "LT:0.4",
            autoTapEnabled = true,
            autoTapIntervalMs = 175L,
            buttonAimEnabled = true,
            buttonAimStickProfile = ButtonAimStickProfile.RADIAL_RESPONSE_CURVE,
            buttonAimAutoCenter = false,
            buttonAimStickUsesTouchPosition = true,
            buttonAimOneShotAlternateEnabled = true,
            buttonAimAlternatePayload = "RT:1.0,X360A",
            buttonAimAlternatePayloadTiming = ButtonAimPayloadTiming.SEND_ON_RELEASE,
            buttonAimAlternateResetHoldDurationMs = 2750L,
            buttonAimAlternateBaseUnlatchDelayMs = 140L,
            buttonAimAlternateDisplayName = "Fire",
            buttonAimAlternateOutput = ButtonAimOutput.LEFT_STICK,
            buttonAimAlternateAutoCenter = true,
            buttonAimAlternateSensitivity = 1.7f,
            buttonAimAlternateInvertY = true,
            buttonAimAlternateStickProfile = ButtonAimStickProfile.RESPONSE_CURVE,
            buttonAimAlternateMouseProfile = ButtonAimMouseProfile.LINEAR_RELATIVE,
            buttonAimAlternateStickFullDisplacementPx = 310f,
            buttonAimAlternateStickDeadzonePx = 12f,
            buttonAimAlternateStickUsesTouchPosition = true,
            buttonAimOutput = ButtonAimOutput.DPAD,
            buttonAimDpadMode = ButtonAimDpadMode.FOUR_WAY,
            buttonAimDpadOrigin = ButtonAimDpadOrigin.INITIAL_TOUCH,
            buttonAimDpadActivationDistancePx = 18f,
            buttonAimAlternateDpadMode = ButtonAimDpadMode.FOUR_WAY,
            buttonAimAlternateDpadOrigin = ButtonAimDpadOrigin.INITIAL_TOUCH,
            buttonAimAlternateDpadActivationDistancePx = 22f,
            buttonAimAlternateHaptics = false
        )

        val restored = json.decodeFromString<Control>(json.encodeToString(source))
        assertEquals(source, restored)
        assertEquals(ButtonAimStickProfile.RADIAL_RESPONSE_CURVE, restored.buttonAimStickProfile)
        assertFalse(restored.buttonAimAutoCenter)
        assertTrue(restored.buttonAimAlternateAutoCenter)
    }
}
